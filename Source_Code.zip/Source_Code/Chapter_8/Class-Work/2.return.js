// Create a function and store it in a variable called 'double'
var two = function (number) {
    // The function takes one input (parameter) called 'number'

    // It returns the result of multiplying that number by 2
    return number * 2;
};

console.log(two(5));
