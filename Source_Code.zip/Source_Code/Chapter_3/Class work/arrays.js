//Creating Array
var fruits = ['apple', 'banana', 'cherry', 'lemon', 'orange'];

//print out the array
console.log(fruits,'\n');

console.log("----Making use of indexing----")

// //index start counting from 0
// console.log("Fruits index:", fruits[2]);

// //Changing Elements
// //Update an array item by specifying its index and setting a new value 
// fruits[1] = 'blueberry';
// console.log("New value in the Array:", fruits);

// var mixedDataType = [42, 'hello', true, {name: 'John'}, [1, 2, 3], false, [1, 2, 3, 6]];
// console.log("Data type Value:", mixedDataType[2]); 

// //5.  Finding Length: 
// console.log("Fruits Length:", fruits.length);

// //6.  Adding Elements: Append new items to the end of the array. 
// fruits.push('date','mango');
// console.log("After-appending:", fruits);

// //7.  Removing Elements: 
// //Remove items from the end or a specific position in the array. 
// console.log("Removed item:",fruits.pop());
// console.log("Array After-pop:", fruits);

// //8.  Joining Arrays:
// var allFruits = fruits.concat(mixedDataType); 
// console.log("Concat:",allFruits); 

// //9.  Finding Index: 
// console.log("Index-Of the value:",allFruits.indexOf('lemon'));

// //10. Turning into a String: 
// // Convert the array into a single string with elements separated by a comma. 
// var mixedString = mixedDataType.join(', ');
// console.log("Coverted String:",mixedString);

// //11.  Building with push: Add new items to the end of the array. 
// var numbers = [];
// numbers.push(1, 2, 3, 5, 6, 7);
// console.log("Numbers Array:",numbers);

// //12.  Adding to the beginning of the array: 
// numbers.unshift(2, 8, 6);
// console.log("Added:",numbers);